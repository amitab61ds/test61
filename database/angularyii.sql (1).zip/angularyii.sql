-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 02, 2016 at 12:32 PM
-- Server version: 5.6.21
-- PHP Version: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `angularyii`
--

-- --------------------------------------------------------

--
-- Table structure for table `article`
--

CREATE TABLE IF NOT EXISTS `article` (
`id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `summary` text COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_assignment`
--

CREATE TABLE IF NOT EXISTS `auth_assignment` (
  `item_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_assignment`
--

INSERT INTO `auth_assignment` (`item_name`, `user_id`, `created_at`) VALUES
('admin', 2, NULL),
('member', 3, 1453204165),
('theCreator', 1, 1452585372);

-- --------------------------------------------------------

--
-- Table structure for table `auth_item`
--

CREATE TABLE IF NOT EXISTS `auth_item` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `rule_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item`
--

INSERT INTO `auth_item` (`name`, `type`, `description`, `rule_name`, `data`, `created_at`, `updated_at`) VALUES
('admin', 1, 'Administrator of this application', NULL, NULL, 1454306717, 1454306717),
('adminArticle', 2, 'Allows admin+ roles to manage articles', NULL, NULL, 1454306715, 1454306715),
('createArticle', 2, 'Allows editor+ roles to create articles', NULL, NULL, 1454306715, 1454306715),
('deleteArticle', 2, 'Allows admin+ roles to delete articles', NULL, NULL, 1454306715, 1454306715),
('editor', 1, 'Editor of this application', NULL, NULL, 1454306716, 1454306716),
('manageUsers', 2, 'Allows admin+ roles to manage users', NULL, NULL, 1454306715, 1454306715),
('member', 1, 'Registered users, members of this site', NULL, NULL, 1454306716, 1454306716),
('premium', 1, 'Premium members. They have more permissions than normal members', NULL, NULL, 1454306716, 1454306716),
('support', 1, 'Support staff', NULL, NULL, 1454306716, 1454306716),
('theCreator', 1, 'You!', NULL, NULL, 1454306717, 1454306717),
('updateArticle', 2, 'Allows editor+ roles to update articles', NULL, NULL, 1454306716, 1454306716),
('updateOwnArticle', 2, 'Update own article', 'isAuthor', NULL, 1454306716, 1454306716),
('usePremiumContent', 2, 'Allows premium+ roles to use premium content', NULL, NULL, 1454306715, 1454306715);

-- --------------------------------------------------------

--
-- Table structure for table `auth_item_child`
--

CREATE TABLE IF NOT EXISTS `auth_item_child` (
  `parent` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `child` varchar(64) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item_child`
--

INSERT INTO `auth_item_child` (`parent`, `child`) VALUES
('theCreator', 'admin'),
('editor', 'adminArticle'),
('editor', 'createArticle'),
('admin', 'deleteArticle'),
('admin', 'editor'),
('admin', 'manageUsers'),
('support', 'member'),
('support', 'premium'),
('editor', 'support'),
('admin', 'updateArticle'),
('updateOwnArticle', 'updateArticle'),
('editor', 'updateOwnArticle'),
('premium', 'usePremiumContent');

-- --------------------------------------------------------

--
-- Table structure for table `auth_rule`
--

CREATE TABLE IF NOT EXISTS `auth_rule` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_rule`
--

INSERT INTO `auth_rule` (`name`, `data`, `created_at`, `updated_at`) VALUES
('isAuthor', 'O:28:"common\\rbac\\rules\\AuthorRule":3:{s:4:"name";s:8:"isAuthor";s:9:"createdAt";i:1454306715;s:9:"updatedAt";i:1454306715;}', 1454306715, 1454306715);

-- --------------------------------------------------------

--
-- Table structure for table `cmenus`
--

CREATE TABLE IF NOT EXISTS `cmenus` (
`id` int(11) NOT NULL,
  `parent_id` tinyint(4) NOT NULL,
  `type` tinyint(4) NOT NULL,
  `name` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `class_name` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `order` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `globalsetting`
--

CREATE TABLE IF NOT EXISTS `globalsetting` (
`id` int(10) NOT NULL,
  `site_title` varchar(100) NOT NULL,
  `admin_mail` varchar(100) NOT NULL,
  `meta_tag` mediumtext NOT NULL,
  `meta_desc` mediumtext NOT NULL,
  `fevicon_icon` varchar(100) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `innerlogo` varchar(100) NOT NULL,
  `contact_details` varchar(10000) NOT NULL,
  `facebook` varchar(100) NOT NULL,
  `twitter` varchar(100) NOT NULL,
  `linkedin` varchar(100) NOT NULL,
  `googleplus` varchar(100) NOT NULL,
  `youtube` varchar(100) NOT NULL,
  `pinterest` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `globalsetting`
--

INSERT INTO `globalsetting` (`id`, `site_title`, `admin_mail`, `meta_tag`, `meta_desc`, `fevicon_icon`, `logo`, `innerlogo`, `contact_details`, `facebook`, `twitter`, `linkedin`, `googleplus`, `youtube`, `pinterest`) VALUES
(1, 'angular yii', 'info@angularyii.com', 'angular yii', 'angular yii', '/uploads/fevicon.ico', '/uploads/site/medium/logo.png', '/uploads/site/medium/innerlogo.png', '<p>angular yii</p>', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `menu_type`
--

CREATE TABLE IF NOT EXISTS `menu_type` (
`id` tinyint(4) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu_type`
--

INSERT INTO `menu_type` (`id`, `name`) VALUES
(1, 'Page'),
(2, 'Custom Link');

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

CREATE TABLE IF NOT EXISTS `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1454306698),
('m141022_115823_create_user_table', 1454306702),
('m141022_115912_create_rbac_tables', 1454306705),
('m141022_115922_create_session_table', 1454306706),
('m150104_153617_create_article_table', 1454306707);

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE IF NOT EXISTS `pages` (
`id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `meta_keywords` varchar(255) NOT NULL,
  `meta_desc` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `page_menu_rel`
--

CREATE TABLE IF NOT EXISTS `page_menu_rel` (
`id` int(11) NOT NULL,
  `pageid` int(11) NOT NULL,
  `parentid` int(11) NOT NULL,
  `level` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `parent_menus`
--

CREATE TABLE IF NOT EXISTS `parent_menus` (
`id` tinyint(4) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `session`
--

CREATE TABLE IF NOT EXISTS `session` (
  `id` char(64) COLLATE utf8_unicode_ci NOT NULL,
  `expire` int(11) NOT NULL,
  `data` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `session`
--

INSERT INTO `session` (`id`, `expire`, `data`) VALUES
('2ano9scvk4dva3dn1r77it3pa3', 1454410262, 0x5f5f666c6173687c613a303a7b7d5f5f72657475726e55726c7c733a32303a222f616e67756c61727969692f6261636b656e642f223b5f5f69647c693a323b),
('3s95g2i94ic9jodjli6g6svba6', 1454393819, 0x5f5f666c6173687c613a303a7b7d5f5f72657475726e55726c7c733a32303a222f616e67756c61727969692f6261636b656e642f223b5f5f69647c693a323b),
('73v3mepi3k0p0c9oqmcu81dhm6', 1454410143, 0x5f5f666c6173687c613a303a7b7d),
('7pggbukon7pheju9vbivmt0957', 1454413859, 0x5f5f666c6173687c613a303a7b7d),
('7qnb7h39q3gvmr5kjjtdnd4c30', 1454331566, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f636170746368617c733a373a226f6f646164646b223b5f5f636170746368612f736974652f63617074636861636f756e747c693a313b),
('avk6qoe77bdiq9etp1e5suj832', 1454411567, 0x5f5f666c6173687c613a303a7b7d5f5f72657475726e55726c7c733a32303a222f616e67756c61727969692f6261636b656e642f223b5f5f69647c693a313b),
('c99s1m1lq7s3obuur6b4vgmbc0', 1454411096, 0x5f5f666c6173687c613a303a7b7d),
('h94g0675rg4mdmdrpqibq9tdq0', 1454414050, 0x5f5f666c6173687c613a303a7b7d5f5f72657475726e55726c7c733a32303a222f616e67756c61727969692f6261636b656e642f223b5f5f69647c693a313b5f5f636170746368612f736974652f636170746368617c733a373a226a6f7a69686578223b5f5f636170746368612f736974652f63617074636861636f756e747c693a313b),
('hgedde8e14tg9luc69cbc94l51', 1454412054, 0x5f5f666c6173687c613a303a7b7d5f5f69647c693a313b),
('i2us51qdbpj6bmr7a8qi51p663', 1454411801, 0x5f5f666c6173687c613a303a7b7d5f5f69647c693a313b),
('mk5duru4cdlc68r0094cba8vm1', 1454333150, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f636170746368617c733a373a226a6f6370746173223b5f5f636170746368612f736974652f63617074636861636f756e747c693a313b),
('tgfbt828nl8s3nr791h7caiu31', 1454312396, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f636170746368617c733a363a226e6164776c6b223b5f5f636170746368612f736974652f63617074636861636f756e747c693a313b);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
`id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `account_activation_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `email`, `password_hash`, `status`, `auth_key`, `password_reset_token`, `account_activation_token`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'amitab.61ds@gmail.com', '$2y$13$eng0s3D1cLev.QeW6ILoEe0nOmQu/ujBZ9KatN40G5fAFyO0cu2WK', 10, 'fPTKbSXFFPt-Q7d1KPN4KMytAWbu4cGQ', NULL, NULL, 1452585372, 1452585372),
(2, 'editor', 'editor@atmant.com', '$2y$13$wFABSd46tH7CA10kjv1NXOQgdso40Ob7DM8VN/Qea1x0J60JO3RGW', 10, '1RWck85SBIPd2DIxquug-QYSV_dkvNmJ', NULL, NULL, 1452852286, 1452852286),
(3, 'member', 'test.61ds@gmail.com', '$2y$13$sGE6gHjTgdtK7oAM4beXLudt14gUjsOVNCl7darLo6GHjKYID0Em2', 1, 'Vw9309wd7ZatYE3hHa-oC3glcj7kQ3_p', NULL, 'QQgsw-CCudwFsGwmSDNOnvJh-HzZPt0f_1453204165', 1453204165, 1453204165);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `article`
--
ALTER TABLE `article`
 ADD PRIMARY KEY (`id`), ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `auth_assignment`
--
ALTER TABLE `auth_assignment`
 ADD PRIMARY KEY (`item_name`,`user_id`);

--
-- Indexes for table `auth_item`
--
ALTER TABLE `auth_item`
 ADD PRIMARY KEY (`name`), ADD KEY `rule_name` (`rule_name`), ADD KEY `idx-auth_item-type` (`type`);

--
-- Indexes for table `auth_item_child`
--
ALTER TABLE `auth_item_child`
 ADD PRIMARY KEY (`parent`,`child`), ADD KEY `child` (`child`);

--
-- Indexes for table `auth_rule`
--
ALTER TABLE `auth_rule`
 ADD PRIMARY KEY (`name`);

--
-- Indexes for table `cmenus`
--
ALTER TABLE `cmenus`
 ADD PRIMARY KEY (`id`), ADD KEY `type` (`type`), ADD KEY `parent_id` (`parent_id`);

--
-- Indexes for table `globalsetting`
--
ALTER TABLE `globalsetting`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu_type`
--
ALTER TABLE `menu_type`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migration`
--
ALTER TABLE `migration`
 ADD PRIMARY KEY (`version`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `url` (`slug`);

--
-- Indexes for table `page_menu_rel`
--
ALTER TABLE `page_menu_rel`
 ADD PRIMARY KEY (`id`), ADD KEY `pageid` (`pageid`), ADD KEY `parentid` (`parentid`);

--
-- Indexes for table `parent_menus`
--
ALTER TABLE `parent_menus`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `session`
--
ALTER TABLE `session`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `username` (`username`), ADD UNIQUE KEY `email` (`email`), ADD UNIQUE KEY `password_reset_token` (`password_reset_token`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `article`
--
ALTER TABLE `article`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cmenus`
--
ALTER TABLE `cmenus`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `globalsetting`
--
ALTER TABLE `globalsetting`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `menu_type`
--
ALTER TABLE `menu_type`
MODIFY `id` tinyint(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `page_menu_rel`
--
ALTER TABLE `page_menu_rel`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `parent_menus`
--
ALTER TABLE `parent_menus`
MODIFY `id` tinyint(4) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `article`
--
ALTER TABLE `article`
ADD CONSTRAINT `article_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

--
-- Constraints for table `auth_assignment`
--
ALTER TABLE `auth_assignment`
ADD CONSTRAINT `auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `auth_item`
--
ALTER TABLE `auth_item`
ADD CONSTRAINT `auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `auth_item_child`
--
ALTER TABLE `auth_item_child`
ADD CONSTRAINT `auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
